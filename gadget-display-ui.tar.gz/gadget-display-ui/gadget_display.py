#!/usr/bin/env python3
"""
Gadget Display Renderer
Renders the tiptop-style terminal UI for the Gadget music sharing device
"""

from PIL import Image, ImageDraw, ImageFont
import time

# Color palette
COLORS = {
    'bg': '#1a1d2e',           # Dark navy background
    'green': '#719253',         # Album box
    'purple': '#9c93dd',        # Time box
    'pink': '#d6697f',          # Pushed by text
    'tan': '#c2995e',           # Weather box
    'border_gray': '#a7afd4',   # Main border & messages
    'dark_red': '#794252',      # Unused for now
    'white': '#ffffff',
    'orange': '#ff8800',        # Spotify code
}

class GadgetDisplay:
    def __init__(self, width=480, height=320, preview_mode=True):
        """
        Initialize the display
        
        Args:
            width: Display width in pixels (default 480)
            height: Display height in pixels (default 320)
            preview_mode: If True, renders to image file. If False, renders to hardware display
        """
        self.width = width
        self.height = height
        self.preview_mode = preview_mode
        
        # Load fonts
        try:
            self.font_tiny = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 7)
            self.font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 8)
            self.font_med = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 10)
            self.font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 16)
        except OSError:
            print("⚠️  Could not load fonts, using default")
            self.font_tiny = ImageFont.load_default()
            self.font_small = ImageFont.load_default()
            self.font_med = ImageFont.load_default()
            self.font_large = ImageFont.load_default()
        
        # Create base image
        self.image = Image.new('RGB', (self.width, self.height), color=COLORS['bg'])
        self.draw = ImageDraw.Draw(self.image)
        
        # Hardware display setup (only if not in preview mode)
        self.display_device = None
        if not preview_mode:
            try:
                # Import will happen when actually deploying to Pi
                # from waveshare_epd import epd3in5
                # self.display_device = epd3in5.EPD()
                pass
            except ImportError:
                print("⚠️  Waveshare library not found - running in preview mode")
                self.preview_mode = True
    
    def draw_slider(self, x, y, width, value, max_val, color):
        """
        Draw a tiptop-style dot slider
        
        Args:
            x, y: Position
            width: Width in pixels
            value: Current value
            max_val: Maximum value
            color: Slider color
        """
        dots = int(width / 2)
        filled = int((value / max_val) * dots)
        
        slider_str = ""
        for i in range(dots):
            if i < filled:
                slider_str += ":#"
            else:
                slider_str += "::"
        
        self.draw.text((x, y), slider_str, font=self.font_tiny, fill=color)
    
    def draw_left_column(self, weather_data, time_data, messages, album_data):
        """
        Draw the left column with all info panels
        
        Args:
            weather_data: dict with 'temp', 'sun', 'rain' (0-100 values)
            time_data: dict with 'time_str', 'hour', 'date_str'
            messages: list of dicts with 'name' and 'preview'
            album_data: dict with album info
        """
        # Top border with header
        self.draw.rectangle([2, 2, 158, 318], outline=COLORS['border_gray'], width=1)
        self.draw.text((5, 0), " Gadget v1.0", font=self.font_tiny, fill=COLORS['border_gray'])
        self.draw.text((90, 0), "Tap to talk ", font=self.font_tiny, fill=COLORS['border_gray'])
        
        # ===== WEATHER BOX =====
        y = 8
        self.draw.rectangle([5, y, 155, y + 55], outline=COLORS['tan'], width=1)
        self.draw.text((8, y - 2), " weather ", font=self.font_tiny, fill=COLORS['tan'])
        
        self.draw.text((8, y + 5), f"temp   {weather_data['temp']}°F", font=self.font_tiny, fill=COLORS['white'])
        self.draw_slider(8, y + 13, 140, weather_data['temp'], 100, COLORS['tan'])
        
        self.draw.text((8, y + 21), "sun", font=self.font_tiny, fill=COLORS['white'])
        self.draw_slider(8, y + 29, 140, weather_data['sun'], 100, COLORS['tan'])
        
        self.draw.text((8, y + 37), "rain", font=self.font_tiny, fill=COLORS['white'])
        self.draw_slider(8, y + 45, 140, weather_data['rain'], 100, COLORS['tan'])
        
        # ===== TIME BOX =====
        y = 70
        self.draw.rectangle([5, y, 155, y + 30], outline=COLORS['purple'], width=1)
        self.draw.text((8, y - 2), " time ", font=self.font_tiny, fill=COLORS['purple'])
        
        self.draw.text((8, y + 5), time_data['time_str'], font=self.font_tiny, fill=COLORS['white'])
        self.draw_slider(8, y + 13, 140, time_data['hour'], 12, COLORS['purple'])
        
        self.draw.text((8, y + 21), time_data['date_str'], font=self.font_tiny, fill=COLORS['white'])
        
        # ===== MESSAGES BOX =====
        y = 107
        self.draw.rectangle([5, y, 155, y + 70], outline=COLORS['border_gray'], width=1)
        self.draw.text((8, y - 2), " messages ", font=self.font_tiny, fill=COLORS['border_gray'])
        
        # Draw up to 3 messages
        for i, msg in enumerate(messages[:3]):
            msg_y = y + 5 + (i * 20)
            self.draw.text((8, msg_y), msg['name'], font=self.font_tiny, fill=COLORS['white'])
            self.draw.text((8, msg_y + 8), f'"{msg["preview"]}"', font=self.font_tiny, fill=COLORS['border_gray'])
        
        # ===== ALBUM BOX =====
        y = 184
        self.draw.rectangle([5, y, 155, y + 128], outline=COLORS['green'], width=1)
        self.draw.text((8, y - 2), " album ", font=self.font_tiny, fill=COLORS['green'])
        
        self.draw.text((8, y + 5), f"{album_data['bpm']} BPM", font=self.font_tiny, fill=COLORS['white'])
        self.draw.text((8, y + 15), f"max     {album_data['duration']}", font=self.font_tiny, fill=COLORS['white'])
        
        self.draw.text((8, y + 27), album_data['artist_1'], font=self.font_tiny, fill=COLORS['white'])
        self.draw.text((8, y + 35), album_data['artist_2'], font=self.font_tiny, fill=COLORS['white'])
        
        self.draw.text((8, y + 47), f'"{album_data["track"]}"', font=self.font_tiny, fill=COLORS['green'])
        
        self.draw.text((8, y + 62), f"pushed by {album_data['pushed_by']}", font=self.font_tiny, fill=COLORS['pink'])
        
        # Sliders
        self.draw_slider(8, y + 75, 140, album_data['bpm'], 200, COLORS['green'])
        
        self.draw.text((8, y + 85), album_data['current_time'], font=self.font_tiny, fill=COLORS['white'])
        self.draw_slider(8, y + 93, 140, album_data['current_seconds'], album_data['total_seconds'], COLORS['green'])
        
        self.draw.text((8, y + 103), "plays", font=self.font_tiny, fill=COLORS['white'])
        self.draw_slider(8, y + 111, 140, album_data['plays'], 100, COLORS['green'])
    
    def draw_album_art(self, artist_1="CINNAMON", artist_2="CHASERS", track="Doorways"):
        """
        Draw the album art and Spotify code on the right side
        
        Args:
            artist_1: First line of artist name
            artist_2: Second line of artist name
            track: Track name
        """
        album_x = 170
        album_y = 10
        album_size = 240
        
        # Gradient for album art (placeholder)
        for i in range(album_size):
            color_val = int(255 * (i / album_size))
            self.draw.rectangle(
                [album_x, album_y + i, album_x + album_size, album_y + i + 1], 
                fill=(color_val, 80, 255 - color_val)
            )
        
        # Album art border
        self.draw.rectangle(
            [album_x, album_y, album_x + album_size, album_y + album_size], 
            outline=COLORS['green'], 
            width=2
        )
        
        # Artist text
        self.draw.text((album_x + 20, album_y + 90), artist_1, font=self.font_large, fill=COLORS['white'])
        self.draw.text((album_x + 30, album_y + 110), artist_2, font=self.font_large, fill=COLORS['white'])
        self.draw.text((album_x + 40, album_y + 130), track, font=self.font_med, fill=COLORS['green'])
        
        # Spotify code bar
        spotify_y = 260
        self.draw.rectangle(
            [album_x, spotify_y, album_x + album_size, spotify_y + 50], 
            fill=COLORS['orange']
        )
        
        # Spotify logo (circle)
        logo_x = album_x + 15
        logo_y = spotify_y + 15
        self.draw.ellipse([logo_x, logo_y, logo_x + 20, logo_y + 20], fill='black')
        
        # Scan bars
        bar_heights = [12, 22, 18, 28, 16, 26, 20, 24, 18, 22, 
                       26, 18, 23, 20, 28, 16, 24, 18, 26, 22,
                       20, 24, 18, 28, 23, 18, 26, 20]
        
        for i, bar_height in enumerate(bar_heights):
            bar_x = album_x + 45 + i * 7
            self.draw.rectangle(
                [bar_x, spotify_y + 10, bar_x + 5, spotify_y + 10 + bar_height], 
                fill='black'
            )
    
    def render(self, weather_data, time_data, messages, album_data):
        """
        Render the complete display
        
        Args:
            weather_data: Weather information
            time_data: Time information
            messages: Message list
            album_data: Album information
        """
        # Clear previous image
        self.image = Image.new('RGB', (self.width, self.height), color=COLORS['bg'])
        self.draw = ImageDraw.Draw(self.image)
        
        # Draw components
        self.draw_left_column(weather_data, time_data, messages, album_data)
        self.draw_album_art(
            artist_1=album_data.get('artist_1', 'CINNAMON'),
            artist_2=album_data.get('artist_2', 'CHASERS'),
            track=album_data.get('track', 'Doorways')
        )
        
        return self.image
    
    def show(self):
        """Display the image (preview mode shows in window, hardware mode pushes to display)"""
        if self.preview_mode:
            # Save and show preview
            self.image.save('/tmp/gadget_preview.png')
            print("💾 Preview saved to /tmp/gadget_preview.png")
            try:
                self.image.show()
            except:
                print("⚠️  Could not open image viewer. Check /tmp/gadget_preview.png")
        else:
            # Push to hardware display
            if self.display_device:
                # Code for Waveshare display would go here
                # self.display_device.display(self.display_device.getbuffer(self.image))
                pass
            else:
                print("⚠️  No hardware display available")


def demo():
    """Demo function with sample data"""
    display = GadgetDisplay(preview_mode=True)
    
    # Sample data
    weather_data = {
        'temp': 72,
        'sun': 60,  # Partly cloudy
        'rain': 0,
    }
    
    time_data = {
        'time_str': '2:47 PM',
        'hour': 2,  # For slider (2/12)
        'date_str': 'Feb 4',
    }
    
    messages = [
        {'name': 'Amy', 'preview': 'Dinner tonight?'},
        {'name': 'Sarah', 'preview': 'See you later!'},
        {'name': 'Mike', 'preview': 'Running late'},
    ]
    
    album_data = {
        'bpm': 120,
        'duration': '2:42 s',
        'artist_1': 'Cinnamon',
        'artist_2': 'Chasers',
        'track': 'Doorways',
        'pushed_by': 'Amy',
        'current_time': '1:30',
        'current_seconds': 90,
        'total_seconds': 162,
        'plays': 73,
    }
    
    # Render and show
    display.render(weather_data, time_data, messages, album_data)
    display.show()
    
    print("✅ Display rendered successfully!")


if __name__ == "__main__":
    demo()
